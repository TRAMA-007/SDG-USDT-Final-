import logging
import os 
import json
import re
import httpx 
from telegram.constants import ParseMode
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    ApplicationBuilder, CommandHandler, ContextTypes, MessageHandler,
    filters, CallbackQueryHandler, ConversationHandler
)
import asyncio


# Configurable parameters
ADMIN_CHAT_ID = 412504520  # Replace with your Telegram user ID
BINANCE_ID = "501340762"
ORDER_TIMEOUT = 15 * 60  # 15 minutes in seconds


# State definitions for conversation
AMOUNT_SELL, CONFIRMATION, PAYMENT_RECEIPT_SELL, PAYMENT_DETAILS_SELL = range(1, 5)
AMOUNT_BUY, CONFIRMATION, PAYMENT_RECEIPT_BUY, PAYMENT_DETAILS_BUY = range(4, 8)  # Adjusted to avoid overlap


# Order storage and ID counter
orders = {}
order_counter = 102 # global order counter


# Admin configurable variables
amount_needed = 100
amount_have = 50
price_per_usdt = 3470 ## I buy from people
status = "online"
sell_price = 3510  # i sell to people 

#user_list = [7876515695, 7081475489, 412504520, 1273627569, 6613490971, 541295179, 5798888880, 5255551516, 7862252523, 6956131847, 7785456730, 2117420644, 7362980831, 1194914127, 1170242614, 5155857979, 539768087, 7058530708, 1685865090, 7463078885, 1450199642, 5001590283, 937713624, 7131187134, 8261741194, 1840215867, 1694665559, 588997074, 590421846, 535953233, 1178710017, 501186331, 7103224620, 7197579678, 1535718157, 116460765, 7189288331, 1550259093, 876042749, 677184899, 5045695545]

users_file = './users.json'

async def sleep (seconds):
    await asyncio.sleep(seconds)

def escape_markdown_v2(text):
    return re.sub(r'([_*\[\]()~`>#\+=|{}.!-])', r'\\\1', text)

async def send_copyable_text(update: Update, context: ContextTypes.DEFAULT_TYPE):
    copy_text = "1234567890ABCDEF"  # The text you want user to copy

    await update.message.reply_text(
        f"Here is your code to copy:\n`{copy_text}`",
        parse_mode=ParseMode.MARKDOWN_V2
    )
    await update.message.reply_text(
    F"Binance ID :     `{BINANCE_ID}`  📑",
    parse_mode=ParseMode.MARKDOWN_V2
    )

async def set_status(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.message.from_user.id
    if user_id != ADMIN_CHAT_ID:
        await update.message.reply_text("🚫 هذا الأمر متخصص للمشرف فقط.")
        return
    
    if not context.args:
        await update.message.reply_text("الرجاء اختيار الحالة\n\nonline ✅\n\noffline 🕹️")
        return
    
    global status

    state = context.args[0].lower()
    if state == 'online':
        status = 'online' 
        await update.message.reply_text("تم ضبط الحالة على Online ✅")
        return
        
    elif state == 'offline':
        status = None 
        await update.message.reply_text("تم ضبط الحالة على Offline 🎯")
        return
        
    else :
        await update.message.reply_text("حدث خطأ ما !!! ")


async def set_amount_needed(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.message.from_user.id
    if user_id != ADMIN_CHAT_ID:
        await update.message.reply_text("🚫 هذا الأمر متخصص للمشرف فقط.")
        return

    if not context.args:
        await update.message.reply_text("❗ الرجاء إرسال كمية USDT المطلوبة بعد الأمر، مثلا:\n/setneed 1000")
        return

    global amount_needed
    try:
        new_amount = float(context.args[0])
        if new_amount == 0:
            amount_needed = None
            await update.message.reply_text(f"تم تصفير الكمية المطلوبة 💯")
            return
        if new_amount < 0:
            raise ValueError()
        amount_needed = new_amount
        await update.message.reply_text(f"✅ تم ضبط كمية USDT المطلوبة إلى {amount_needed}.")
    except ValueError:
        await update.message.reply_text("❌ الرجاء إرسال رقم صالح للكمية المطلوبة.")

async def set_amount_have(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.message.from_user.id
    if user_id != ADMIN_CHAT_ID:
        await update.message.reply_text("🚫 هذا الأمر متخصص للمشرف فقط.")
        return

    if not context.args:
        await update.message.reply_text("❗ الرجاء إرسال كمية USDT المطلوبة بعد الأمر، مثلا:\n/sethave 1000")
        return

    global amount_have
    try:
        new_amount = float(context.args[0])
        if new_amount == 0 :
            amount_have = None
            await update.message.reply_text(f"تم تصفير الكمية المتوفرة 💯")
            return
        if new_amount < 0:
            raise ValueError()
        amount_have = new_amount
        await update.message.reply_text(f"✅ تم ضبط كمية USDT المتوفرة إلى {amount_have}.")
    except ValueError:
        await update.message.reply_text("❌ الرجاء إرسال رقم صالح للكمية المطلوبة.")

async def payment_timeout(context: ContextTypes.DEFAULT_TYPE, order_id):
    await asyncio.sleep(ORDER_TIMEOUT)
    order = orders.get(order_id)
    if order and not order["payment_received"]:
        orders[order_id]["status"] = "cancelled"
        user_id = order["user_id"]
        await context.bot.send_message(chat_id=user_id, text="⏰ تم إلغاء طلبك لعدم استلام إيصال الدفع خلال 15 دقيقة.")
        await context.bot.send_message(chat_id=ADMIN_CHAT_ID, text=f"❌ تم إلغاء طلب {order_id} لعدم استلام إيصال الدفع.")
        logging.info(f"Order {order_id} cancelled due to timeout")


async def set_buy_price(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.message.from_user.id
    if user_id != ADMIN_CHAT_ID:
        await update.message.reply_text("🚫 هذا الأمر متخصص للمشرف فقط.")
        return

    if not context.args:
        await update.message.reply_text("❗ الرجاء إرسال السعر لكل USDT بعد الأمر، مثلا:\n/setprice 550")
        return

    global price_per_usdt
    try:
        new_price = float(context.args[0])
        if new_price <= 0:
            raise ValueError()
        price_per_usdt = new_price
        await update.message.reply_text(f"✅ تم ضبط سعر الشراء لكل USDT إلى {price_per_usdt} SDG.")
    except ValueError:
        await update.message.reply_text("❌ الرجاء إرسال رقم صالح للسعر.")


async def set_sell_price(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.message.from_user.id
    if user_id != ADMIN_CHAT_ID:
        await update.message.reply_text('هذا الأمر خاص بالأدمن فقط ! 🔐')
        return
    
    try:
        global sell_price
        price = float(context.args[0])
        if price <= 0:
            raise ValueError()
        sell_price = price 
        await update.message.reply_text(f"تم ضبط سعر البيع الى {sell_price} بنجاح ! ✅")
    except Exception:
        await update.message.reply_text("❌ الرجاء إرسال رقم صالح للسعر.")

async def price_list(update: Update, context: ContextTypes.DEFAULT_TYPE):
    userName = update.message.from_user.first_name
    await update.message.reply_text(f"💱 مرحباً بك يا {userName}\n\n🔸سعر البيع ← {sell_price}\n\n🔹سعر الشراء ← {price_per_usdt}")


async def is_online(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if status is None:
        await update.message.reply_text("التاجر غير متصل حالياً ، يرجى المحاولة في وقت آخر! ⏳")
    else:
        await update.message.reply_text("التاجر متصل حالياً ، يمكنك اجراء معاملاتك بكل سرعة ✅")


async def explain(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "🏷️ خطوات بيع وشراء الUSDT مقابل الجنيه في البوت : \n\n"
        "🔸 ابدأ العملية بواسطة الأمر /sell أو /buy\n\n"
        "🔹 حدد الكمية التي تريد بيعها أو شرائها\n\n"
        "🔸 قم بالدفع على الid الذي سيظهر و ارفع الاشعار\n\n"
        "🔹 قم بإرسال معلومات حسابك البنكي\n\n"
        "🔸 سيتم تأكيد طلبك و تستلم إشعارك في خلال 15 دقيقة كحد أقصى\n\n\n"
        "🔐 جميع المعلومات خاصة ولا يتم مشاركتها مع أي طرف ثالث ، اذا واجهتك أي مشكلة في استخدام البوت يمكنك التواصل مع المطور\n"
        "⚙️ @T_R_A_M_A"
    )
async def send_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if len(context.args) < 2:
        await update.message.reply_text("Usage: /send_message <chat_id> <message>")
        return
    
    chat_id = context.args[0]
    message = " ".join(context.args[1:])  # Join the rest as message text

    try:
        await context.bot.send_message(chat_id=chat_id, text=message)
        await update.message.reply_text("Message sent successfully!")
    except Exception as e:
        await update.message.reply_text(f"Failed to send message: {e}")
    
async def add (update: Update, context: ContextTypes.DEFAULT_TYPE):
    userName = update.message.from_user.first_name
    userID = update.message.from_user.id

    users_file = 'users.json'

    # Load existing user IDs from JSON file
    if os.path.exists(users_file):
        with open(users_file, 'r', encoding='utf-8') as file:
            try:
                users = json.load(file)
                if not isinstance(users, list):
                    users = []
            except json.JSONDecodeError:
                users = []
    else:
        users = []

    # Append userID if not present
    if userID not in users:
        users.append(userID)
        with open(users_file, 'w', encoding='utf-8') as file:
            json.dump(users, file, ensure_ascii=False, indent=2)


    await update.message.reply_text('user added succesfully!! ✅')

async def isOG(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.message.from_user.id
    global users_file
    # Load existing user IDs from JSON file
    try:
        with open(users_file, 'r', encoding='utf-8') as file:
            users = json.load(file)
            if not isinstance(users, list):
                users = []
    except FileNotFoundError:
        users = []
    
    # Add user if not present
    if user_id not in users:
        users.append(user_id)
        with open(users_file, 'w', encoding='utf-8') as file:
            json.dump(users, file, indent=2)
        
        await context.bot.send_message(
            chat_id=ADMIN_CHAT_ID,
            text=f'تم دخول مستخدم جديد 🌐\n\n@{update.message.from_user.username or update.message.from_user.first_name}'
        )
        

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    userName = update.message.from_user.first_name
    user_id = update.message.from_user.id
    
    # Remove all orders of this user to "restart"
    orders_to_remove = [oid for oid, order in orders.items() if order["user_id"] == user_id]
    for oid in orders_to_remove:
        del orders[oid]
        

    await isOG(update, context)  # pass update and context

    await update.message.reply_photo(
        'https://ibb.co/3YSYFbvX',
        caption="- تاجر موثق على OKX 💯\n\n- فوق ال900 معاملة مكتملة 🏷\n\n- شكراً لثقتكم بنا ⭐️"
    )
    await sleep(3)
    await update.message.reply_text(
        f"🔸 مرحباً بك يا {userName}\n\n"
        "📲 الأوامر المتاحة :\n\n"
        "/sell ———— بـيـع USDT مقابل الجنيه 🏷️\n\n"
        "/buy ———— شــراء USDT مقابل الجنيه 🔖\n\n"
        "/price ———— عرض أسعار البيع و الشراء 💱\n\n"
        "/online ———— عرض حالة التاجر متصل أو لا 🌐\n\n"
        "/rate ———— لعرض أسعار صرف العملات الأجنبية 🏦\n\n"
        "/explain ———— شرح كيفية استخدام البوت ⚙️"
    )


# /sell command handler
async def sell(update: Update, context: ContextTypes.DEFAULT_TYPE):

    userID = update.message.from_user.id
    userU = update.message.from_user.username
    await isOG(update, context)
    
    if amount_needed is None or price_per_usdt is None or amount_needed == 0:
        await update.message.reply_text("⚠️ الـكمـيـة مـمـتـلـئـة حـالـيـاً ، الرجاء المحاولة لاحقاً")
        return ConversationHandler.END

    if status is None:
        await update.message.reply_text("التاجر أوفلاين حالياً أو لا يقبل عروض! 📰 ")
        return ConversationHandler.END
    
    await update.message.reply_text(
        f"📩 الرجاء إرسال كمية USDT التي ترغب في بيعها.\n\n"
        f"💰 الـسـعـر الحالي لكل usdt هـو ← {price_per_usdt}ج\n\n"
        f"📊 الكمية المطلوبة حالياً ←		{amount_needed} usdt."
    )
    return AMOUNT_SELL


async def receive_sell_amount(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.message.from_user
    amount_text = update.message.text.strip()
    
    try:
        amount = float(amount_text)
        if amount <= 0:
            raise ValueError()
    except ValueError:
        await update.message.reply_text("❌ الرجاء إدخال كمية صحيحة بصيغة رقمية (مثلاً 75 أو 210)!")
        return AMOUNT_SELL

    if amount_needed is not None and amount > amount_needed:
        await update.message.reply_text(
            f"⚠️ الكمية التي ترغب ببيعها ({amount}) أكبر من الكمية المطلوبة حالياً ({amount_needed}).\n"
            "الرجاء إدخال كمية مناسبة."
        )
        return AMOUNT_SELL

    context.user_data["pending_amount"] = amount

    keyboard = [
        [
            InlineKeyboardButton("تـأكـيـد ✅", callback_data='confirm_amount_sell_yes'),
            InlineKeyboardButton("إلــغــاء ❌", callback_data='confirm_amount_sell_no')
        ]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    await update.message.reply_text(
        f"سـوف يـتـم فـتـح طلـب الآن\n\nهل أنت متأكد أنك تريد بـيـع {amount} USDT؟",
        reply_markup=reply_markup
    )
    return CONFIRMATION  # A new state for confirmation



# /buy command handler - user pays SDG to buy USDT
async def buy(update: Update, context: ContextTypes.DEFAULT_TYPE):

    userID = update.message.from_user.id
    userU = update.message.from_user.username
    await isOG(update, context)

    
    if amount_have is None or sell_price is None or amount_have == 0:
        await update.message.reply_text("⚠️ الـكمـيـة مـنـتـهـيـة حـالـيـاً ، الرجاء المحاولة لاحقاً")
        return ConversationHandler.END

    if status is None:
        await update.message.reply_text("التاجر أوفلاين حالياً أو لا يقبل عروض! 📰 ")
        return ConversationHandler.END
    
    await update.message.reply_text(
        f"📩 الرجاء إرسال كمية USDT التي ترغب في شرائها.\n\n"
        f"💰 السعر الحالي لكل USDT للبيع ←		{sell_price}ج.\n\n"
        f"📊 الكمية المتوفرة حالياً ←		{amount_have} USDT."
    )
    return AMOUNT_BUY


async def receive_buy_amount(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.message.from_user
    amount_text = update.message.text.strip()

    try:
        amount = float(amount_text)
        if amount <= 0:
            raise ValueError()
    except ValueError:
        await update.message.reply_text("❌ الرجاء إدخال كمية صحيحة بصيغة رقمية (مثلاً 75 أو 210)!")
        return AMOUNT_BUY

    if amount_have is not None and amount > amount_have:
        await update.message.reply_text(
            f"⚠️ الكمية التي ترغب بشرائها ({amount}) أكبر من الكمية المتوفرة حالياً ({amount_have}).\n"
            "الرجاء إدخال كمية مناسبة."
        )
        return AMOUNT_BUY

    context.user_data["pending_amount"] = amount

    keyboard = [
        [
            InlineKeyboardButton("تـأكـيـد ✅", callback_data='confirm_amount_buy_yes'),
            InlineKeyboardButton("إلــغــاء ❌", callback_data='confirm_amount_buy_no')
        ]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    await update.message.reply_text(
        f"سـوف يـتـم فـتـح طلـب الآن\n\nهل أنت متأكد أنك تريد شــراء {amount} USDT؟",
        reply_markup=reply_markup
    )
    return CONFIRMATION


async def confirmation_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    data = query.data

    if data == 'confirm_amount_sell_yes':
        amount = context.user_data.get("pending_amount")
        # Proceed to create sell order with amount
        return await proceed_with_sell_order(update , context, amount)

    elif data == 'confirm_amount_sell_no':
        await query.edit_message_text("تم إلغاء طلب البيع.")
        return ConversationHandler.END

    elif data == 'confirm_amount_buy_yes':
        amount = context.user_data.get("pending_amount")
        # Proceed to create buy order with amount
        return await proceed_with_buy_order(update, context, amount)

    elif data == 'confirm_amount_buy_no':
        await query.edit_message_text("تم إلغاء طلب الشراء.")
        return ConversationHandler.END

    
async def proceed_with_sell_order(update: Update, context: ContextTypes.DEFAULT_TYPE, amount: float):
    query = update.callback_query
    user = query.from_user
    userID = query.from_user.id
    global order_counter

    order_counter += 1
    order_id = order_counter

    orders[order_id] = {
        "user_id": user.id,
        "username": user.username or user.first_name,
        "amount": amount,
        "status": "pending_payment",
        "payment_received": False,
        "payment_details_received": False,
        "type": "sell"
    }

    total_sdg = round(amount * price_per_usdt, 2)

    # Notify admin
    await context.bot.send_message(
        chat_id=ADMIN_CHAT_ID,
        text=(
            f"📥 طلب بــيــع جديد!\n\n"
            f"🌐 البائع : @{orders[order_id]['username']}\n\n"
            f"💵 الكمية : {amount} USDT\n\n"
            f"🏦 المبلغ : {total_sdg} SDG\n\n"
            f"🏷️ معرّف الطلب : {order_id}\n\n"
            f"🔐 آيــدي : {userID}"
        )
    )

    # Edit confirmation message with order details
    await query.edit_message_text(
        f"🏷️ رقم الطلب الخاص بك :   {order_id}\n\n"
        f"💰 الرجاء إرسال {amount}$ إلى حساب Binance أدنـاه\n\n"
        f"🌐 اسم المستخدم : TRAMAZOOL\n\n"
        f"📊 ستستلم حوالي {total_sdg} جنيه للطلب الحالي.\n\n"
        f"📸 ثم أرسل صورة إيصال الدفع هنا خلال 15 دقيقة.\n\n"
        f"🔐 يمكنك الغاء الطلب عبر (   /cancel 		{order_id} )"
    )
    
    # Send additional message with bank details
    await query.message.reply_text(
        f"Binance :      `{BINANCE_ID}`   📑",
        parse_mode=ParseMode.MARKDOWN_V2
    )

    context.user_data["current_order_id"] = order_id
    asyncio.create_task(payment_timeout(context, order_id))

    return PAYMENT_RECEIPT_SELL


async def proceed_with_buy_order(update: Update, context: ContextTypes.DEFAULT_TYPE, amount: float):
    query = update.callback_query
    user = query.from_user
    userID = query.from_user.id
    global order_counter

    order_counter += 1
    order_id = order_counter

    orders[order_id] = {
        "user_id": user.id,
        "username": user.username or user.first_name,
        "amount": amount,
        "status": "pending_payment",
        "payment_received": False,
        "payment_details_received": False,
        "type": "buy"
    }

    total_sdg = round(amount * sell_price, 2)

    # Notify admin
    await context.bot.send_message(
        chat_id=ADMIN_CHAT_ID,
        text=(
            f"🏦 !طلب شــــراء جديد\n\n"
            f"🌐 المشتري : @{orders[order_id]['username']}\n\n"
            f"💵 الكمية : {amount} USDT\n\n"
            f"🏧 المبلغ :{total_sdg} SDG\n\n"
            f"🏷️ معرّف الطلب : {order_id}\n\n"
            f"🔐 آيــدي : {userID}"
        )
    )

    # Edit initial confirmation message with details
    await query.edit_message_text(
        f"🏷️ رقم الطلب الخاص بك :   {order_id}.\n\n"
        f"💰 الرجاء ارسال {total_sdg} جنيه الى رقم الحساب أدناه.\n\n"
        f"💠 الإســم : سيد خالد محمد.\n\n"
        f"🏛️ الــفــرع: الــمـــزاد.\n\n"
        f"📸 ثم أرسل صورة إيصال الدفع هنا خلال 15 دقيقة.\n\n"
        f"🔐 يمكنك الغاء الطلب عبر 	( /cancel {order_id} )"
    )

    # Send additional bank details as new message
    await query.message.reply_text(
        "Bankak :      `3139163`   📑",
        parse_mode=ParseMode.MARKDOWN_V2
    )

    context.user_data["current_order_id"] = order_id
    asyncio.create_task(payment_timeout(context, order_id))

    return PAYMENT_RECEIPT_BUY


# Shared payment receipt receiver (works for both buy and sell)
async def receive_receipt(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.message.from_user
    order_id = context.user_data.get("current_order_id")

    if not order_id or orders.get(order_id, {}).get("status") != "pending_payment":
        await update.message.reply_text("⚠️ لا يوجد طلب نشط لإيصال الدفع أو تم استلام الدفع بالفعل.")
        # Determine proper state to wait for receipt depending on order type
        return PAYMENT_RECEIPT_SELL if orders.get(order_id, {}).get("type") == "sell" else PAYMENT_RECEIPT_BUY

    if update.message.photo:
        orders[order_id]["payment_received"] = True
        photo_file = update.message.photo[-1].file_id
        amount = orders[order_id]['amount']

        if orders[order_id]['type'] == 'buy':
            total_sdg = round(amount * sell_price, 2)
        else:
            total_sdg = round(amount * price_per_usdt, 2)  # corrected variable name

        await context.bot.send_photo(
            chat_id=ADMIN_CHAT_ID,
            photo=photo_file,
            caption=(
                f"📸 إيصال دفع من : @{orders[order_id]['username']}\n\n"
                f"🏷️ للطلب رقم : {order_id}.\n\n"
                f"💵 الكمية : {amount} USDT\n\n"
                f"💰 الـمـبـلـغ : {total_sdg} ج"
            )
        )

        keyboard = [
            [
                InlineKeyboardButton("❌ إلغاء العملية (احتيال مشتبه به)", callback_data=f"cancel_{order_id}"),
                InlineKeyboardButton("✅ إرسال إيصال SDG", callback_data=f"send_sdg_{order_id}")
            ]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        await context.bot.send_message(chat_id=ADMIN_CHAT_ID, text="اختر الإجراء المناسب لهذا الطلب:", reply_markup=reply_markup)

        if orders[order_id]['type'] == "sell":
            await update.message.reply_text(
                '🏦 أرسل معلومات الدفع الخاصة بك:\n\n'
                '🏷️ رقـم حـسـاب بـنـكـك أو مـاي كـاشـي\n\n'
                '📄 إسـم مـالـك الـحـسـاب (مـهـم)\n\n\n'
                'أرسل معلومات حسابك في رسالة واحدة من فضلك ⏳'
            )
            return PAYMENT_DETAILS_SELL
        else:
            await update.message.reply_text(
                '🏦 أرسل معلومات الدفع الخاصة بك:\n\n'
                '🏷️ آيــدي بـايـنـانـس \n\n'
                '📄 إسـم الـمـسـتخـدم في الـمنـصـة (مـهـم)\n\n\n'
                'أرسل معلومات حسابك في رسالة واحدة من فضلك ⏳'
            )
            return PAYMENT_DETAILS_BUY

    else:
        await update.message.reply_text("❗ الرجاء إرسال صورة إشعار دفع صحيحة.")
        if orders[order_id]['type'] == "sell":
            return PAYMENT_RECEIPT_SELL
        else:
            return PAYMENT_RECEIPT_BUY



# Shared payment details receiver (works for both buy and sell)
async def receive_payment_details(update: Update, context: ContextTypes.DEFAULT_TYPE):
    order_id = context.user_data.get("current_order_id")
    if not order_id or orders.get(order_id, {}).get("status") != "pending_payment":
        await update.message.reply_text("⚠️ لا يوجد طلب نشط لاستلام تفاصيل الدفع.")
        return ConversationHandler.END

    payment_details = update.message.text.strip()
    orders[order_id]["payment_details"] = payment_details
    orders[order_id]["payment_details_received"] = True
    orders[order_id]["status"] = "processing"

    await update.message.reply_text("⏳ طلبك الآن قـيـد الـمـعـالـجـة....")

    await context.bot.send_message(
        chat_id=ADMIN_CHAT_ID,
        text=(
            f"📝 تفاصيل دفع لـ : 	@{orders[order_id]['username']}\n\n"
            f"🏷️ للطلب رقم :		{order_id}\n\n"
            f"{payment_details}"        )
    )

    return ConversationHandler.END


# Handle admin buttons callback
async def button_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    data = query.data
    admin_id = query.from_user.id

    if admin_id != ADMIN_CHAT_ID:
        await query.answer(text="🚫 غير مصرح بالدخول", show_alert=True)
        return

    if data.startswith("cancel_"):
        order_id = int(data.split("_")[1])
        order = orders.get(order_id)
        if order and order.get("status") != "cancelled":
            order["status"] = "cancelled"
            await context.bot.send_message(
                chat_id=order["user_id"],
                text="❌ تم إلغاء طلبك من قبل الإدارة بسبب مشتبه به."
            )
            await query.edit_message_text(text=f"تم إلغاء الطلب {order_id}.")
    elif data.startswith("send_sdg_"):
        order_id = int(data.split("_")[2])
        order = orders.get(order_id)
        if order:
            order["status"] = "waiting_sdg_receipt"
            context.user_data["sdg_order_id"] = order_id
            await query.edit_message_text(text="📷 الرجاء إرسال صورة إشعار SDG ليتم تحويلها للمستخدم.")


# Receive SDG receipt photo from admin
async def sdg_receipt_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    admin_id = update.message.from_user.id
    if admin_id != ADMIN_CHAT_ID:
        return

    order_id = context.user_data.get("sdg_order_id")
    if not order_id:
        await update.message.reply_text("⚠️ لا يوجد طلب ينتظر إيصال SDG.")
        return

    if update.message.photo:
        photo_file = update.message.photo[-1].file_id
        order = orders.get(order_id)
        if order:
            await context.bot.send_photo(
                chat_id=order["user_id"],
                photo=photo_file,
                caption="إشعار الدفع الخاص بك 📄\n\nتم إكمال طلبك بنجاح ✅"
            )
            order["status"] = "complete"
            await update.message.reply_text(f"✅ تم إرسال إيصال SDG وتم إكمال الطلب {order_id}.")
            context.user_data.pop("sdg_order_id")
            global amount_needed
            global amount_have
            if orders[order_id]['type'] == "sell":
                amount_needed -= order["amount"]
            else:
                amount_have -= order["amount"]
    else:
        await update.message.reply_text("❗ الرجاء إرسال صورة صحيحة.")

async def cancel_order(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.message.from_user.id
    if not context.args:
        await update.message.reply_text("❗ الرجاء إرسال رقم الطلب الصحيح. مثال: /cancel 1")
        return

    try:
        order_id = int(context.args[0])
    except ValueError:
        await update.message.reply_text("❌ معرف الطلب يجب أن يكون رقمًا صحيحًا.")
        return

    order = orders.get(order_id)
    if not order:
        await update.message.reply_text("⚠️ لم يتم العثور على طلب بهذا المعرف.")
        return

    if order["user_id"] != user_id:
        await update.message.reply_text("🚫 لا يمكنك إلغاء طلب ليس ملكك.")
        return

    if order["status"] != "pending_payment":
        await update.message.reply_text("⚠️ لا يمكن إلغاء هذا الطلب. حالته حالياً ليست معلقة.")
        return

    order["status"] = "cancelled"
    await update.message.reply_text(f"✅ تم إلغاء طلبك رقم {order_id} بنجاح.")

    # Notify admin
    await context.bot.send_message(
        chat_id=ADMIN_CHAT_ID,
        text=f"❌ المستخدم @{order.get('username')} ألغى الطلب رقم {order_id}."
    )

# Admin command to view all orders history
async def orders_history(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.message.from_user.id
    if user_id != ADMIN_CHAT_ID:
        await update.message.reply_text("🚫 هذه الأوامر مخصصة فقط للمشرف.")
        return

    if not orders:
        await update.message.reply_text("⚠️ لا توجد طلبات بعد.")
        return

    messages = []
    for order_id, order in sorted(orders.items()):
        messages.append(
            f"معرّف: {order_id}\n"
            f"المستخدم: @{order.get('username')}\n"
            f"النوع: {order.get('type')}\n"
            f"الكمية: {order.get('amount')}\n"
            f"الحالة: {order.get('status')}\n"
            "--------------------"
        )

    # Split messages if too long
    chunk_size = 5
    for i in range(0, len(messages), chunk_size):
        await update.message.reply_text("\n".join(messages[i:i+chunk_size]))

async def users_data(update: Update, context: ContextTypes.DEFAULT_TYPE) : 
    user_id = update.message.from_user.id
    if user_id != ADMIN_CHAT_ID:
        await update.message.reply_text("🚫 هذه الأوامر مخصصة فقط للمشرف.")
        return 
    
    await update.message.reply_text(f"قائمة المستخدمين 🔐\n\n{user_list}")

async def cast(update: Update, context: ContextTypes.DEFAULT_TYPE):
    # Check if the command is a reply to another message
    if not update.message.reply_to_message:
        await update.message.reply_text("❗ الرجاء الرد على رسالة لتتم إعادة إرسالها.")
        return

    # Load user list safely
    try:
        with open(users_file, 'r', encoding='utf-8') as file:
            user_list = json.load(file)
    except FileNotFoundError:
        await update.message.reply_text("⚠️ قائمة المستخدمين غير موجودة.")
        return
    except json.JSONDecodeError:
        await update.message.reply_text("⚠️ خطأ في قراءة قائمة المستخدمين.")
        return

    length = len(user_list)
    await update.message.reply_text(f'جـارٍ الإذاعـة إلى {length} مـسـتـخدم ⏳')

    for user_id in user_list:
        try:
            # Forward the replied-to message to each user
            await context.bot.forward_message(
                chat_id=user_id,
                from_chat_id=update.message.chat_id,
                message_id=update.message.reply_to_message.message_id
            )
            await asyncio.sleep(1)
        except Exception as e:
            print(f"Failed to forward message to {user_id}: {e}")

    await update.message.reply_text("✅ تم إرسال الرسالة لجميع المستخدمين.")

async def clear_all_user_orders(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.message.from_user.id

    # Collect keys of orders to delete for this user
    user_order_ids = [oid for oid, o in orders.items() if o["user_id"] == user_id]

    # Remove the orders from the dictionary
    for oid in user_order_ids:
        del orders[oid]

    await update.message.reply_text(
        f"✅ تم حذف {len(user_order_ids)} طلبًا تمامًا من السجل، يمكنك الآن بدء طلب جديد."
    )

async def rate(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try:
        url = "https://currencyrates-trama-007-trama-007.vercel.app/rates"
        async with httpx.AsyncClient() as client:
            response = await client.get(url)
            response.raise_for_status()  # Raise for HTTP errors
            data = response.json()
            
            usd = data['sdg rates']['USD']
            busd = data['sdg rates']['Black_USD']
            
            aed = data['sdg rates']['AED']
            baed = data['sdg rates']['Black_AED']
            
            sar = data['sdg rates']['SAR']
            bsar = data['sdg rates']['Black_SAR']
            
            egp = data['sdg rates']['EGP']
            begp = data['sdg rates']['Black_EGP']
            
            qar = data['sdg rates']['QAR']
            bqar = data['sdg rates']['Black_QAR']
            
            await update.message.reply_text(f'📰 أسـعـار صـرف الـعـمـلات الأجـنـبـيـة :\n\n'
                                            f'ـ🇺🇸 الـدولار الأمـريـكـي : \n'
                                            f'🏦 بـنـك الـخـرطـوم ← {usd}\n'
                                            f'💱 الـسـوق الـبـديـل ← {busd}\n\n'
                                            f'ـ🇦🇪 الـدرهـم الإمـاراتـي : \n'
                                            f'🏦 بـنـك الـخـرطـوم ← {aed}\n'
                                            f'💱 الـسـوق الـبـديـل ← {baed}\n\n'
                                            f'ـ🇸🇦 الريال السعودي : \n'
                                            f'🏦 بـنـك الـخـرطـوم ← {sar}\n'
                                            f'💱 الـسـوق الـبـديـل ← {bsar}\n\n'
                                            f'ـ🇪🇬 الجنيه المصري : \n'
                                            f'🏦 بـنـك الـخـرطـوم ← {egp}\n'
                                            f'💱 الـسـوق الـبـديـل ← {begp}\n\n'
                                            f'ـ🇶🇦 الريال القطري : \n'
                                            f'🏦 بـنـك الـخـرطـوم ← {qar}\n'
                                            f'💱 الـسـوق الـبـديـل ← {bqar}')
    except Exception as e:
        await update.message.reply_text(f'Error: {e}')

async def isgroup(update: Update, context: ContextTypes.DEFAULT_TYPE):
    type = update.effective_chat.type
    isgroup = type == 'group' or type == 'supergroup'
    await update.message.reply_text(type)
    await update.message.reply_text(isgroup)
    

def main():
    application = ApplicationBuilder().token("7950937823:AAHdxpfKOzLYjx9hZRwsxY_kdez8Jba8c8Q").build()

    conv_handler_sell = ConversationHandler(
        entry_points=[CommandHandler('sell', sell)],
        states={
            AMOUNT_SELL: [MessageHandler(filters.TEXT & ~filters.COMMAND, receive_sell_amount)],
            CONFIRMATION: [CallbackQueryHandler(confirmation_handler, pattern='^confirm_amount_sell_')],
            PAYMENT_RECEIPT_SELL: [
                MessageHandler(filters.PHOTO & ~filters.COMMAND, receive_receipt),
                MessageHandler(~filters.PHOTO & ~filters.COMMAND, receive_receipt),
            ],
            PAYMENT_DETAILS_SELL: [MessageHandler(filters.TEXT & ~filters.COMMAND, receive_payment_details)]
        },
        fallbacks=[]
    )

    conv_handler_buy = ConversationHandler(
        entry_points=[CommandHandler('buy', buy)],
        states={
            AMOUNT_BUY: [MessageHandler(filters.TEXT & ~filters.COMMAND, receive_buy_amount)],
            CONFIRMATION: [CallbackQueryHandler(confirmation_handler, pattern='^confirm_amount_buy_')],
            PAYMENT_RECEIPT_BUY: [
                MessageHandler(filters.PHOTO & ~filters.COMMAND, receive_receipt),
                MessageHandler(~filters.PHOTO & ~filters.COMMAND, receive_receipt),
            ],
            PAYMENT_DETAILS_BUY: [MessageHandler(filters.TEXT & ~filters.COMMAND, receive_payment_details)]
        },
        fallbacks=[]
    )

    application.add_handler(CommandHandler('start', start))
    application.add_handler(CommandHandler('setneed', set_amount_needed))
    application.add_handler(CommandHandler('sethave', set_amount_have))
    application.add_handler(CommandHandler('setbuy', set_buy_price))
    application.add_handler(CommandHandler('setSell', set_sell_price))
    application.add_handler(CommandHandler('setstatus', set_status))
    application.add_handler(CommandHandler('price', price_list))
    application.add_handler(CommandHandler('online', is_online))
    application.add_handler(CommandHandler('explain', explain))
    application.add_handler(CommandHandler('add', add))
    application.add_handler(CommandHandler('send', send_message))
    application.add_handler(CommandHandler('copy', send_copyable_text))
    application.add_handler(CommandHandler('cancel', cancel_order))
    application.add_handler(CommandHandler('orders', orders_history))
    application.add_handler(CommandHandler('list', users_data))
    application.add_handler(CommandHandler('cast', cast))
    application.add_handler(CommandHandler('clear', clear_all_user_orders))
    application.add_handler(CommandHandler('rate', rate))
    application.add_handler(CommandHandler('type', isgroup))


    application.add_handler(conv_handler_sell)
    application.add_handler(conv_handler_buy)
    application.add_handler(CallbackQueryHandler(button_handler))
    application.add_handler(MessageHandler(filters.PHOTO & filters.User(ADMIN_CHAT_ID), sdg_receipt_handler))

    application.run_polling()



if __name__ == '__main__':
    main()



















